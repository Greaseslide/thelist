<template>
    <div class="flex flex-col justify-center items-center min-h-[88vh]">
        <h1 class="font-bold !text-[170rem] mb-[-6vh]">404</h1>
        <h2 v-t="'info.page_not_found'" class="!text-[40rem]" />
        <a v-t="'actions.back_to_home'" role="button" href="/" />
    </div>
</template>
